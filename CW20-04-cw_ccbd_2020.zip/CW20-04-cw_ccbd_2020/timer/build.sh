docker build -t timer .
docker tag timer chanthruuthaya/timer:latest
docker push chanthruuthaya/timer:latest