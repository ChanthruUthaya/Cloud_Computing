docker build -t producer .
docker tag producer chanthruuthaya/producer:latest
docker push chanthruuthaya/producer:latest