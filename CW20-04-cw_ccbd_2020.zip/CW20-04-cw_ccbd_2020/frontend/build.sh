docker build -t frontend .
docker tag frontend chanthruuthaya/frontend:latest
docker push chanthruuthaya/frontend:latest
